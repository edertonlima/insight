<?php
/*
* Attachment Page
*/
?>
 
<?php get_header(); ?>
<?php
	get_template_part( 'loop', 'attachment' );
?>
<?php get_footer(); ?>