<?php
/**
 * Single Product Thumbnails
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.5.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post, $product, $woocommerce;

$attachment_ids = $product->get_gallery_attachment_ids();

if ( $attachment_ids ) {
	?>
	<div class="gridblock-owlcarousel-wrap clearfix">
	<div id="owl-woocommerce-slideshow-thumbnails" class="owl-carousel owl-thumbnail-element">
	<?php
		if ( has_post_thumbnail() ) {

		$image       		= get_the_post_thumbnail( $post->ID, apply_filters( 'shop_thumbnail_image_size', 'shop_thumbnail' ) );
		$image_title 		= esc_attr( get_the_title( get_post_thumbnail_id() ) );
		$image_link  		= wp_get_attachment_url( get_post_thumbnail_id() );
		$attachment_count   = count( $product->get_gallery_attachment_ids() );

		if ( $attachment_count > 0 ) {
			$gallery = '[product-gallery]';
		} else {
			$gallery = '';
		}
		echo '<div class="gridblock-thumbnail-element">';
		echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '%s', $image ), '', $post->ID, "owl-slide-image" );
		echo '</div>';
	} 
	?>
	<?php

		$loop = 0;

		foreach ( $attachment_ids as $attachment_id ) {

			$image_link = wp_get_attachment_url( $attachment_id );

			if ( ! $image_link )
				continue;

			$classes[] = 'image-'.$attachment_id;

			$image       = wp_get_attachment_image( $attachment_id, apply_filters( 'shop_thumbnail_image_size', 'shop_thumbnail' ) );
			$image_class = esc_attr( implode( ' ', $classes ) );
			$image_title = esc_attr( get_the_title( $attachment_id ) );

			echo '<div class="gridblock-thumbnail-element">';
			echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', sprintf( '%s', $image ), $attachment_id, $post->ID, "owl-slide-image"  );
			echo '</div>';

			$loop++;
		}

	?>
	</div>
	</div>
	<?php
}