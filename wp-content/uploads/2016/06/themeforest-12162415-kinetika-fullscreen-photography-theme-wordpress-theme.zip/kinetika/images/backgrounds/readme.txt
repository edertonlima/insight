Textures from:
http://pictoyd.deviantart.com/art/Free-Photosh-Wood-Texture-pack-201190587
http://mediamilitia.com/wallpaper-textures-27-free-images/